package com.example.foodyshop.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.foodyshop.R;
import com.example.foodyshop.config.Constant;
import com.example.foodyshop.helper.JWT;
import com.example.foodyshop.model.Respond;
import com.example.foodyshop.service.APIService;
import com.example.foodyshop.service.DataService;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        initUi();

        btnLogin.setOnClickListener(v -> login());
    }

    private void initUi() {
        btnLogin = findViewById(R.id.btn_signin);
    }

    private void login(){
        String username = "0347954696";
        String password = "123456";

        Map<String, String> mMap = new HashMap<>();
        mMap.put("username", username);
        mMap.put("password", password);

        String token = JWT.createToken(mMap, System.currentTimeMillis() + 60 * 1000);
        DataService dataService = APIService.getService();
        Call<Respond> callback = dataService.login(token);
        callback.enqueue(new Callback<Respond>() {
            @Override
            public void onResponse(@NonNull Call<Respond> call, @NonNull Response<Respond> response) {
                if(response.isSuccessful() && response.body() != null){
                    Respond res = response.body();
                    if(res.getStatus() == 1){
                        // lưu token mới khi đăng nhập thành công
                        SharedPreferences.Editor editor = getSharedPreferences(Constant.KEY_USER_PREFERENCES, MODE_PRIVATE).edit();
                        editor.putString(Constant.KEY_TOKEN_LOGIN, res.getMsg());
                        editor.apply();
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                    }else{
                        // Show lỗi khi đăng nhập false
                        Toast.makeText(getApplicationContext(), res.getMsg(), Toast.LENGTH_SHORT).show();
                    }
                    Log.e("ddd", "onResponse: " + res );
                }
            }

            @Override
            public void onFailure(@NonNull Call<Respond> call, @NonNull Throwable t) {

            }
        });

    }
}