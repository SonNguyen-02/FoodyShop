package com.example.foodyshop.config;

public class Constant {

    public static final String KEY_USER_PREFERENCES = "key_user_preferences";
    public static final String KEY_TOKEN_LOGIN = "key_token_login";

    public static final String KEY_TOPIC = "key_topic";
    public static final String KEY_CATEGORY = "key_category";
}
