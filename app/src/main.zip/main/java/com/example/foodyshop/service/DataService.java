package com.example.foodyshop.service;


import com.example.foodyshop.model.ProductModel;
import com.example.foodyshop.model.Respond;
import com.example.foodyshop.model.TopicModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface DataService {

    @FormUrlEncoded
    @POST("login")
    Call<Respond> login(@Field("token") String token);

    @FormUrlEncoded
    @POST("get_all_topic")
    Call<List<TopicModel>> getAllTopic(@Field("token") String token);

    @FormUrlEncoded
    @POST("get_total_page_product_in_topic")
    Call<Integer> getTotalPageProductInTopic(@Field("token") String token,
                                             @Field("topic_id") int topicId,
                                             @Field("is_sale") boolean isSale);

    @FormUrlEncoded
    @POST("get_all_product_in_topic")
    Call<List<ProductModel>> getAllProductInTopic(@Field("token") String token,
                                                  @Field("topic_id") int topicId,
                                                  @Field("current_page") int currentPage,
                                                  @Field("is_sale") boolean isSale);

    @FormUrlEncoded
    @POST("get_total_page_product_in_category")
    Call<Integer> getTotalPageProductInCategory(@Field("token") String token,
                                                @Field("category_id") int categoryId,
                                                @Field("is_sale") boolean isSale);

    @FormUrlEncoded
    @POST("get_all_product_in_category")
    Call<List<ProductModel>> getAllProductInCategory(@Field("token") String token,
                                                     @Field("category_id") int categoryId,
                                                     @Field("current_page") int currentPage,
                                                     @Field("is_sale") boolean isSale);


}
