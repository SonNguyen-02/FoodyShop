package com.example.foodyshop.helper;

import android.util.Log;

import androidx.annotation.NonNull;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.SecretKey;

import io.jsonwebtoken.Jwt;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

public class JWT {

    private static final SecretKey PRIVATE_KEY = Keys.hmacShaKeyFor(Decoders.BASE64.decode("Rm9PZHlTaG9QX3NlY3JldEtleVl5KiMxMjA0JV4mNDUxODgxIyEhMjI0NWRzZEREIzJFZGVk"));

    public static String createToken() {
        return Jwts.builder()
                .setExpiration(new Date(System.currentTimeMillis() + 60 * 1000)) //a java.util.Date
                .setIssuedAt(new Date())
                .signWith(PRIVATE_KEY, SignatureAlgorithm.HS256)
                .compact();
    }

    public static String createToken(Map<String, String> map, long timeExp) {
        return Jwts.builder()
                .setClaims(map)
                .setExpiration(new Date(timeExp)) //a java.util.Date
                .setIssuedAt(new Date())
                .signWith(PRIVATE_KEY, SignatureAlgorithm.HS256)
                .compact();
    }

    @NonNull
    public static Jwt decodeToken(String token) {
        Jwt jwt = Jwts.parserBuilder().setSigningKey(PRIVATE_KEY).build().parse(token);
        Log.e("ddd", "decodeToken: " + jwt.getBody());
        return jwt;
    }

}
