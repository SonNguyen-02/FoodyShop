package com.example.foodyshop.activity;

import static com.example.foodyshop.config.Constant.KEY_TOPIC;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.foodyshop.R;
import com.example.foodyshop.adapter.TopicAdapter;
import com.example.foodyshop.fragment.AccountFragment;
import com.example.foodyshop.fragment.HomeFragment;
import com.example.foodyshop.fragment.TopicFragment;
import com.example.foodyshop.fragment.NotificationFragment;
import com.example.foodyshop.fragment.OrderFragment;
import com.example.foodyshop.fragment.SearchFragment;
import com.example.foodyshop.model.TopicModel;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity implements TopicAdapter.IOnclickTopicItem {

    public static final int TOTAL_ITEM_PRODUCT = 2;
    public static int HEIGHT_DEVICE;
    public static int WIDTH_DEVICE;
    private int mCurrentFragment;

    private ImageView imgMenu, imgSearch, imgCart;
    private TextView tvTitle;
    private RelativeLayout rlSearch;
    private BottomNavigationView mBottomNavigationView;
    private TopicFragment mTopicFragment;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initUi();
        mTopicFragment = new TopicFragment();
        mBottomNavigationView.setOnItemSelectedListener(this::onItemSelected);
        mCurrentFragment = R.id.menu_home;
        replaceMainFrame(new HomeFragment());

        rlSearch.setOnClickListener(view -> addFragmentToMainLayout(new SearchFragment(), SearchFragment.class.getName()));
        imgSearch.setOnClickListener(view -> addFragmentToMainLayout(new SearchFragment(), SearchFragment.class.getName()));
        imgMenu.setOnClickListener(view -> addFragmentToMainLayout(mTopicFragment, TopicFragment.class.getName()));
        imgCart.setOnClickListener(view->{
            Intent intent = new Intent(getApplicationContext(), CartActivity.class);
            startActivity(intent);
        });
    }

    private void initUi() {
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        HEIGHT_DEVICE = metrics.heightPixels;
        WIDTH_DEVICE = metrics.widthPixels;
        imgMenu = findViewById(R.id.img_menu_category);
        imgSearch = findViewById(R.id.img_search);
        imgCart = findViewById(R.id.img_cart);
        tvTitle = findViewById(R.id.tv_title);
        rlSearch = findViewById(R.id.rl_search);
        mBottomNavigationView = findViewById(R.id.menu_nav);
    }

    private void replaceMainFrame(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.main_frame, fragment);
        transaction.commit();
    }

    private void addFragmentToMainLayout(Fragment fragment, String name) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.anim_fade_in, R.anim.anim_left_out, R.anim.anim_right_in, R.anim.anim_fade_out);
        transaction.add(R.id.fl_main_layout, fragment);
        transaction.addToBackStack(name);
        transaction.commit();
    }

    public void removeFragmentFromMainLayout() {
        getSupportFragmentManager().popBackStack();
    }

//    public void goToHome(){
//        mBottomNavigationView.setSelectedItemId(R.id.menu_home);
//    }

    @SuppressLint("NonConstantResourceId")
    private boolean onItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (mCurrentFragment != id) {
            if (id == R.id.menu_home) {
                tvTitle.setVisibility(View.GONE);
                imgSearch.setVisibility(View.GONE);
                rlSearch.setVisibility(View.VISIBLE);
            } else {
                tvTitle.setVisibility(View.VISIBLE);
                imgSearch.setVisibility(View.VISIBLE);
                rlSearch.setVisibility(View.GONE);
            }
            switch (id) {
                case R.id.menu_home:
                    replaceMainFrame(new HomeFragment());
                    break;
                case R.id.menu_order:
                    replaceMainFrame(new OrderFragment());
                    tvTitle.setText(R.string.menu_order);
                    break;
                case R.id.menu_notification:
                    replaceMainFrame(new NotificationFragment());
                    tvTitle.setText(R.string.menu_notification);
                    break;
                case R.id.menu_account:
                    replaceMainFrame(new AccountFragment());
                    tvTitle.setText(R.string.menu_account);
                    break;
            }
            mCurrentFragment = id;
        }
        return true;
    }

    @Override
    public void onclickTopicItem(TopicModel topic) {
        Intent intent = new Intent(this, DetailTopicActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable(KEY_TOPIC, topic);
        intent.putExtras(bundle);
        startActivity(intent);
    }
}